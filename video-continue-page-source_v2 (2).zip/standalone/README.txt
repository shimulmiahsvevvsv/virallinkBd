Static version (যেকোনো hosting-এ deploy করুন: Netlify, Vercel, GitHub Pages, cPanel...)
1. index.html খুলে TARGET_LINK এ আপনার লিংক বসান।
2. images/hero.jpg আপনার ছবি দিয়ে replace করুন (অথবা IMAGE_URL বদলান)।
3. index.html + images ফোল্ডার upload করলেই হবে।
