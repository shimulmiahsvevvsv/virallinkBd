export function openInChrome(url: string) {
  const ua = navigator.userAgent || "";
  const isAndroid = /Android/i.test(ua);
  const isIOS = /iPhone|iPad|iPod/i.test(ua);

  try {
    const u = new URL(url);
    if (isAndroid) {
      // Android: force open in Chrome app
      const intent = `intent://${u.host}${u.pathname}${u.search}${u.hash}#Intent;scheme=${u.protocol.replace(":", "")};package=com.android.chrome;S.browser_fallback_url=${encodeURIComponent(url)};end`;
      window.location.href = intent;
      return;
    }
    if (isIOS) {
      // iOS: Chrome URL scheme (falls back to normal tab if Chrome missing)
      const scheme = u.protocol === "https:" ? "googlechromes" : "googlechrome";
      window.location.href = `${scheme}://${u.host}${u.pathname}${u.search}${u.hash}`;
      setTimeout(() => window.open(url, "_blank"), 1200);
      return;
    }
  } catch {
    /* fall through */
  }
  window.open(url, "_blank", "noopener,noreferrer");
}

export function isInAppBrowser() {
  if (typeof navigator === "undefined") return false;
  return /FBAN|FBAV|FB_IAB|FBIOS|Instagram|Messenger|Line\/|MicroMessenger|TikTok|musical_ly/i.test(
    navigator.userAgent || "",
  );
}

export async function copyLink(url: string) {
  try {
    await navigator.clipboard.writeText(url);
    return true;
  } catch {
    return false;
  }
}
