// ====== এখানে আপনার ছবি ও লিংক বসান ======
// ছবি বদলাতে: public/images/hero.jpg ফাইলটি আপনার ছবি দিয়ে replace করুন
// অথবা নিচে পুরো image URL দিন।
export const IMAGE_URL = "/images/hero.jpg";

// এখানে আপনার লিংক দিন (https:// সহ)
export const TARGET_LINK = "https://example.com";

export const HEADING_TEXT = "ভিডিও গুলো দেখতে এখনই continue বাটন click করুন";
