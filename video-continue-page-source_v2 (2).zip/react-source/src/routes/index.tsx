import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { HEADING_TEXT, IMAGE_URL, TARGET_LINK } from "@/config";
import { copyLink, isInAppBrowser, openInChrome } from "@/lib/open-in-chrome";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ভিডিও দেখুন — Continue করুন" },
      { name: "description", content: "ভিডিও গুলো দেখতে এখনই continue বাটন click করুন।" },
      { property: "og:title", content: "ভিডিও দেখুন — Continue করুন" },
      { property: "og:description", content: "ভিডিও গুলো দেখতে এখনই continue বাটন click করুন।" },
    ],
  }),
  component: Index,
});

function Index() {
  const [open, setOpen] = useState(false);
  const [inApp, setInApp] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    setInApp(isInAppBrowser());
  }, []);

  return (
    <main className="mx-auto flex min-h-screen w-full max-w-md flex-col items-center justify-center gap-6 px-5 py-8">
      <img
        src={IMAGE_URL}
        alt="Preview"
        className="w-full rounded-2xl object-cover shadow-card"
      />

      <p className="text-center text-xl font-semibold leading-relaxed text-foreground">
        {HEADING_TEXT}
      </p>

      <button type="button" onClick={() => setOpen(true)} className="btn-continue">
        Continue
      </button>

      {open && (
        <div className="modal-backdrop" onClick={() => setOpen(false)}>
          <div
            className="modal-card"
            role="dialog"
            aria-modal="true"
            onClick={(e) => e.stopPropagation()}
          >
            <h2 className="text-lg font-bold text-foreground">Chrome ব্রাউজারে খুলুন</h2>
            <p className="mt-2 text-sm text-muted-foreground">
              ভিডিও দেখতে লিংকটি external Chrome browser-এ খুলতে হবে। খুলতে চান?
            </p>
            {inApp && (
              <p className="mt-3 rounded-lg bg-muted p-3 text-xs text-muted-foreground">
                আপনি Facebook ব্রাউজারে আছেন। "Chrome-এ খুলুন" চাপুন। না খুললে উপরের ডানদিকের ⋮ মেনু থেকে
                "Open in Chrome / Open in browser" চাপুন, অথবা লিংক কপি করে Chrome-এ paste করুন।
              </p>
            )}
            {inApp && (
              <button
                type="button"
                className="btn-cancel mt-3 w-full"
                onClick={async () => {
                  setCopied(await copyLink(TARGET_LINK));
                }}
              >
                {copied ? "কপি হয়েছে ✓" : "লিংক কপি করুন"}
              </button>
            )}
            <div className="mt-5 flex gap-3">
              <button
                type="button"
                className="btn-cancel"
                onClick={() => setOpen(false)}
              >
                বাতিল
              </button>
              <button
                type="button"
                className="btn-open"
                onClick={() => {
                  openInChrome(TARGET_LINK);
                  setOpen(false);
                }}
              >
                Chrome-এ খুলুন
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
